package com.signals.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

object Backtest {
    fun run(sym: String, cfg: Cfg): String {
        val client = OkHttpClient()
        val all = ArrayList<Candle>()
        var end = System.currentTimeMillis()
        for (page in 0 until 5) {
            val url = "https://data-api.binance.vision/api/v3/klines?symbol=$sym&interval=1m&limit=1000&endTime=$end"
            val body = client.newCall(Request.Builder().url(url).build()).execute()
                .use { it.body?.string() ?: "[]" }
            val arr = JSONArray(body)
            if (arr.length() == 0) break
            val chunk = ArrayList<Candle>()
            for (k in 0 until arr.length()) {
                val a = arr.getJSONArray(k)
                chunk.add(Candle(a.getLong(0), a.getDouble(1), a.getDouble(2), a.getDouble(3), a.getDouble(4)))
            }
            all.addAll(0, chunk)
            end = chunk.first().t - 1
        }
        if (all.isNotEmpty()) all.removeAt(all.size - 1)
        var n = 0
        var w = 0
        val e = cfg.expiryMin
        for (i in 320 until all.size - e) {
            val sub = all.subList(maxOf(0, i - 399), i + 1)
            val s = Strategies.evaluate(sub, cfg) ?: continue
            n++
            if ((all[i + e].c - all[i].c) * s.dir > 0) w++
        }
        val rate = if (n > 0) 100.0 * w / n else 0.0
        return "Strategy ${cfg.strat} · $sym · 1m · expiry ${e}m · ${all.size} candles\n" +
            "$n signals, win rate ${"%.1f".format(rate)}%\n" +
            "Break-even ≈ 54% at 85% payout (ties counted as losses). Small samples mislead — treat under ~200 signals as noise."
    }
}
