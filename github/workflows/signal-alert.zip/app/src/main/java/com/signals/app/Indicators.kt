package com.signals.app

import kotlin.math.abs
import kotlin.math.max

data class Candle(val t: Long, val o: Double, val h: Double, val l: Double, val c: Double)

object Ind {
    fun smma(src: DoubleArray, n: Int): DoubleArray {
        val out = DoubleArray(src.size) { Double.NaN }
        if (src.size < n) return out
        var s = 0.0
        for (i in 0 until n) s += src[i]
        out[n - 1] = s / n
        for (i in n until src.size) out[i] = (out[i - 1] * (n - 1) + src[i]) / n
        return out
    }

    fun ema(src: DoubleArray, n: Int): DoubleArray {
        val out = DoubleArray(src.size) { Double.NaN }
        if (src.size < n) return out
        var s = 0.0
        for (i in 0 until n) s += src[i]
        out[n - 1] = s / n
        val k = 2.0 / (n + 1)
        for (i in n until src.size) out[i] = src[i] * k + out[i - 1] * (1 - k)
        return out
    }

    fun sma(src: DoubleArray, n: Int): DoubleArray {
        val out = DoubleArray(src.size) { Double.NaN }
        var s = 0.0
        for (i in src.indices) {
            s += src[i]
            if (i >= n) s -= src[i - n]
            if (i >= n - 1) out[i] = s / n
        }
        return out
    }

    // Alligator lines are plotted shifted forward: value shown at bar i = raw[i - shift]
    fun shifted(raw: DoubleArray, shift: Int, i: Int): Double =
        if (i - shift >= 0) raw[i - shift] else Double.NaN

    fun demarker(c: List<Candle>, n: Int): DoubleArray {
        val up = DoubleArray(c.size)
        val dn = DoubleArray(c.size)
        for (i in 1 until c.size) {
            up[i] = max(c[i].h - c[i - 1].h, 0.0)
            dn[i] = max(c[i - 1].l - c[i].l, 0.0)
        }
        val su = sma(up, n)
        val sd = sma(dn, n)
        return DoubleArray(c.size) { i ->
            val d = su[i] + sd[i]
            if (su[i].isNaN() || d == 0.0) Double.NaN else su[i] / d
        }
    }

    fun momentum(c: List<Candle>, n: Int): DoubleArray =
        DoubleArray(c.size) { i -> if (i >= n) (c[i].c / c[i - n].c - 1.0) * 100.0 else Double.NaN }

    fun atr(c: List<Candle>, n: Int): DoubleArray {
        val tr = DoubleArray(c.size) { i ->
            if (i == 0) c[i].h - c[i].l
            else maxOf(c[i].h - c[i].l, abs(c[i].h - c[i - 1].c), abs(c[i].l - c[i - 1].c))
        }
        return smma(tr, n)
    }

    fun adx(c: List<Candle>, n: Int): DoubleArray {
        val size = c.size
        val tr = DoubleArray(size)
        val pdm = DoubleArray(size)
        val mdm = DoubleArray(size)
        for (i in 1 until size) {
            val up = c[i].h - c[i - 1].h
            val dn = c[i - 1].l - c[i].l
            pdm[i] = if (up > dn && up > 0) up else 0.0
            mdm[i] = if (dn > up && dn > 0) dn else 0.0
            tr[i] = maxOf(c[i].h - c[i].l, abs(c[i].h - c[i - 1].c), abs(c[i].l - c[i - 1].c))
        }
        val str = smma(tr, n)
        val sp = smma(pdm, n)
        val sm = smma(mdm, n)
        val dx = DoubleArray(size) { i ->
            val t = str[i]
            if (t.isNaN() || t == 0.0) 0.0 else {
                val pdi = 100 * sp[i] / t
                val mdi = 100 * sm[i] / t
                if (pdi + mdi == 0.0) 0.0 else 100 * abs(pdi - mdi) / (pdi + mdi)
            }
        }
        return smma(dx, n)
    }
}
