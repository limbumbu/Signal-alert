package com.signals.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            logView.text = Store.readLog(this@MainActivity).ifBlank { "No signals yet." }
            h.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val cfg = Store.loadCfg(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 48, 32, 32)

        val title = TextView(this)
        title.text = "Signal Alert"
        title.textSize = 24f
        root.addView(title)

        val rg = RadioGroup(this)
        val ra = RadioButton(this); ra.text = "Strategy A – original indicators"; ra.id = 101
        val rb = RadioButton(this); rb.text = "Strategy B – pullback system"; rb.id = 102
        rg.addView(ra); rg.addView(rb)
        rg.check(if (cfg.strat == 'A') 101 else 102)
        root.addView(rg)

        val sym = EditText(this); sym.hint = "Symbol (e.g. BTCUSDT)"; sym.setText(Store.symbol(this))
        val exp = EditText(this); exp.hint = "Expiry minutes"; exp.inputType = InputType.TYPE_CLASS_NUMBER
        exp.setText(cfg.expiryMin.toString())
        val win = EditText(this); win.hint = "Entry window seconds"; win.inputType = InputType.TYPE_CLASS_NUMBER
        win.setText(cfg.windowSec.toString())
        root.addView(sym); root.addView(exp); root.addView(win)

        fun persist() {
            Store.save(
                this,
                if (rg.checkedRadioButtonId == 101) 'A' else 'B',
                sym.text.toString().trim().uppercase(),
                exp.text.toString().toIntOrNull() ?: 2,
                win.text.toString().toIntOrNull() ?: 15
            )
        }

        val start = Button(this); start.text = "Start alerts"
        start.setOnClickListener {
            persist()
            startForegroundService(Intent(this, SignalService::class.java))
        }
        val stop = Button(this); stop.text = "Stop alerts"
        stop.setOnClickListener { stopService(Intent(this, SignalService::class.java)) }
        val battery = Button(this); battery.text = "Battery: allow background"
        battery.setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        val bt = Button(this); bt.text = "Backtest (last ~3.5 days)"
        val btView = TextView(this)
        bt.setOnClickListener {
            persist()
            btView.text = "Running…"
            val c = Store.loadCfg(this)
            val s = Store.symbol(this)
            Thread {
                val r = try { Backtest.run(s, c) } catch (e: Exception) { "Error: ${e.message}" }
                runOnUiThread { btView.text = r }
            }.start()
        }
        root.addView(start); root.addView(stop); root.addView(battery); root.addView(bt); root.addView(btView)

        val logTitle = TextView(this); logTitle.text = "\nSignal log"; logTitle.textSize = 18f
        root.addView(logTitle)
        logView = TextView(this)
        root.addView(logView)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
