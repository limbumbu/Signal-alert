package com.signals.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class SignalService : Service() {
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    @Volatile private var running = false
    private val candles = ArrayList<Candle>()
    private var cfg = Cfg()
    private var symbol = "BTCUSDT"
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var activeDir = 0
    private var activeRef = 0.0
    private var activeAtr = 0.0
    private var activeUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        cfg = Store.loadCfg(this)
        symbol = Store.symbol(this)
        createChannels()
        val n = Notification.Builder(this, "status")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Signal Alert running")
            .setContentText("$symbol 1m · Strategy ${cfg.strat}")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        if (!running) {
            running = true
            Thread { connect() }.start()
        }
        return START_STICKY
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("status", "Status", NotificationManager.IMPORTANCE_LOW))
        val ch = NotificationChannel("signals", "Trade signals", NotificationManager.IMPORTANCE_HIGH)
        ch.enableVibration(true)
        nm.createNotificationChannel(ch)
    }

    private fun connect() {
        try {
            val url = "https://data-api.binance.vision/api/v3/klines?symbol=$symbol&interval=1m&limit=600"
            val body = client.newCall(Request.Builder().url(url).build()).execute()
                .use { it.body?.string() ?: "[]" }
            val arr = JSONArray(body)
            synchronized(candles) {
                candles.clear()
                for (k in 0 until arr.length() - 1) {
                    val a = arr.getJSONArray(k)
                    candles.add(Candle(a.getLong(0), a.getDouble(1), a.getDouble(2), a.getDouble(3), a.getDouble(4)))
                }
            }
        } catch (e: Exception) {
            retry(); return
        }
        val req = Request.Builder().url("wss://data-stream.binance.vision/ws/${symbol.lowercase()}@kline_1m").build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) { handleMsg(text) }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { retry() }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { retry() }
        })
    }

    private fun retry() {
        if (running) handler.postDelayed({ Thread { connect() }.start() }, 5000)
    }

    private fun handleMsg(text: String) {
        try {
            val k = JSONObject(text).getJSONObject("k")
            val price = k.getString("c").toDouble()
            checkWindow(price)
            if (k.getBoolean("x")) {
                val c = Candle(k.getLong("t"), k.getString("o").toDouble(),
                    k.getString("h").toDouble(), k.getString("l").toDouble(), price)
                val snapshot = synchronized(candles) {
                    if (candles.isNotEmpty() && candles.last().t == c.t) candles[candles.size - 1] = c
                    else candles.add(c)
                    while (candles.size > 700) candles.removeAt(0)
                    ArrayList(candles)
                }
                val s = Strategies.evaluate(snapshot, cfg)
                if (s != null) fire(s, price)
            }
        } catch (e: Exception) {
        }
    }

    private fun fire(s: Signal, price: Double) {
        val now = System.currentTimeMillis()
        activeDir = s.dir
        activeRef = price
        activeAtr = s.atr
        activeUntil = now + cfg.windowSec * 1000L
        val f = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val dirTxt = if (s.dir > 0) "CALL ▲" else "PUT ▼"
        val title = "$dirTxt $symbol · expiry ${cfg.expiryMin} min"
        val text = "Enter between ${f.format(Date(now))} and ${f.format(Date(activeUntil))}. " +
            "After that the entry is stale — skip. ${s.reason}"
        notify(2, "signals", title, text, cfg.windowSec * 1000L)
        Store.log(this, "${f.format(Date(now))} $dirTxt $symbol @ $price (Strategy ${cfg.strat}) valid to ${f.format(Date(activeUntil))} — ${s.reason}")
    }

    private fun checkWindow(price: Double) {
        if (activeDir == 0) return
        if (System.currentTimeMillis() > activeUntil) { activeDir = 0; return }
        val move = (price - activeRef) * activeDir
        if (move > 0.25 * activeAtr) invalidate("Price already ran with the signal — chasing, skip")
        else if (move < -0.25 * activeAtr) invalidate("Price moved against the signal — skip")
    }

    private fun invalidate(msg: String) {
        activeDir = 0
        getSystemService(NotificationManager::class.java).cancel(2)
        notify(3, "status", "Signal expired", msg, 20000L)
        Store.log(this, "   ↳ expired: $msg")
    }

    private fun notify(id: Int, channel: String, title: String, text: String, timeoutMs: Long) {
        val n = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setTimeoutAfter(timeoutMs)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(id, n)
    }

    override fun onDestroy() {
        running = false
        ws?.cancel()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
