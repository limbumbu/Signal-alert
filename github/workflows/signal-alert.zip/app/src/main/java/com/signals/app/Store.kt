package com.signals.app

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", Context.MODE_PRIVATE)

    fun loadCfg(c: Context): Cfg {
        val sp = p(c)
        return Cfg(
            strat = (sp.getString("strat", "B") ?: "B")[0],
            expiryMin = sp.getInt("exp", 2),
            windowSec = sp.getInt("win", 15)
        )
    }

    fun symbol(c: Context): String = p(c).getString("sym", "BTCUSDT") ?: "BTCUSDT"

    fun save(c: Context, strat: Char, sym: String, exp: Int, win: Int) {
        p(c).edit().putString("strat", strat.toString()).putString("sym", sym)
            .putInt("exp", exp).putInt("win", win).apply()
    }

    @Synchronized
    fun log(c: Context, line: String) {
        val old = (p(c).getString("log", "") ?: "").split("\n").filter { it.isNotBlank() }
        val n = (listOf(line) + old).take(40)
        p(c).edit().putString("log", n.joinToString("\n")).apply()
    }

    fun readLog(c: Context): String = p(c).getString("log", "") ?: ""
}
