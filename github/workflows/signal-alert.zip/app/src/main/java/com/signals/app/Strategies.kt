package com.signals.app

import kotlin.math.abs

data class Signal(val dir: Int, val reason: String, val atr: Double)

data class Cfg(
    var strat: Char = 'B',
    var jp: Int = 15, var js: Int = 7,
    var tp: Int = 10, var ts: Int = 6,
    var lp: Int = 5, var ls: Int = 4,
    var demP: Int = 10, var momP: Int = 12,
    var adxMin: Double = 22.0,
    var expiryMin: Int = 2,
    var windowSec: Int = 15
)

object Strategies {
    fun evaluate(c: List<Candle>, g: Cfg): Signal? {
        if (c.size < 320) return null
        val i = c.size - 1
        val med = DoubleArray(c.size) { (c[it].h + c[it].l) / 2 }
        val jr = Ind.smma(med, g.jp)
        val tr = Ind.smma(med, g.tp)
        val lr = Ind.smma(med, g.lp)
        fun jaw(x: Int) = Ind.shifted(jr, g.js, x)
        fun teeth(x: Int) = Ind.shifted(tr, g.ts, x)
        fun lips(x: Int) = Ind.shifted(lr, g.ls, x)
        val dem = Ind.demarker(c, g.demP)
        val mom = Ind.momentum(c, g.momP)
        val atrV = Ind.atr(c, 14)[i]
        if (atrV.isNaN()) return null
        val bull = lips(i) > teeth(i) && teeth(i) > jaw(i)
        val bear = lips(i) < teeth(i) && teeth(i) < jaw(i)

        if (g.strat == 'A') {
            if (bull && mom[i] > 0 && dem[i - 1] <= 0.5 && dem[i] > 0.5)
                return Signal(1, "Alligator bullish + Momentum>0 + DeMarker crossed up 0.5", atrV)
            if (bear && mom[i] < 0 && dem[i - 1] >= 0.5 && dem[i] < 0.5)
                return Signal(-1, "Alligator bearish + Momentum<0 + DeMarker crossed down 0.5", atrV)
            return null
        }

        val adx = Ind.adx(c, 14)[i]
        if (adx.isNaN() || adx < g.adxMin) return null
        val closes5 = ArrayList<Double>()
        var k = i
        while (k >= 0) { closes5.add(c[k].c); k -= 5 }
        closes5.reverse()
        val m5 = closes5.toDoubleArray()
        val e50 = Ind.ema(m5, 50)
        val m5Up = m5.last() > e50.last()
        val m5Dn = m5.last() < e50.last()
        val widening = abs(lips(i) - jaw(i)) > abs(lips(i - 3) - jaw(i - 3))

        if (bull && widening && m5Up && dem[i - 1] <= 0.30 && dem[i] > 0.30 &&
            mom[i] > mom[i - 1] && c[i].c > c[i].o && c[i].c > jaw(i))
            return Signal(1, "Uptrend pullback ended: ADX ${adx.toInt()}, M5 up, DeMarker back above 0.30", atrV)
        if (bear && widening && m5Dn && dem[i - 1] >= 0.70 && dem[i] < 0.70 &&
            mom[i] < mom[i - 1] && c[i].c < c[i].o && c[i].c < jaw(i))
            return Signal(-1, "Downtrend pullback ended: ADX ${adx.toInt()}, M5 down, DeMarker back below 0.70", atrV)
        return null
    }
}
