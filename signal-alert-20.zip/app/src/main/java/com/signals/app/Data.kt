package com.signals.app

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class Market(val sym: String, val forex: Boolean) {
    val label: String get() = if (forex) sym.substring(0, 3) + "/" + sym.substring(3) else sym
}

object Markets {
    val crypto = listOf("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "LTCUSDT")
        .map { Market(it, false) }
    val forex = listOf("EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD", "EURGBP", "EURJPY", "GBPJPY")
        .map { Market(it, true) }

    fun parse(s: String): Market? {
        val x = s.trim().uppercase().replace("/", "")
        return when {
            x.endsWith("USDT") && x.length >= 6 -> Market(x, false)
            x.length == 6 -> Market(x, true)
            else -> null
        }
    }

    // mode: 0 all, 1 crypto, 2 forex, 3 single pair
    fun forMode(mode: Int, single: String): List<Market> = when (mode) {
        0 -> crypto + forex
        1 -> crypto
        2 -> forex
        else -> listOfNotNull(parse(single))
    }
}

object Feed {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val pool = Executors.newFixedThreadPool(4)
    private val data = ConcurrentHashMap<String, ArrayList<Candle>>()
    private const val UA = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private fun http(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
            return r.body?.string() ?: ""
        }
    }

    private fun fetchRange(m: Market, from: Long, to: Long): List<Candle> {
        val out = ArrayList<Candle>()
        if (!m.forex) {
            var cur = from
            for (page in 0 until 12) {
                val url = "https://data-api.binance.vision/api/v3/klines?symbol=${m.sym}&interval=1m&startTime=$cur&endTime=$to&limit=1000"
                val arr = JSONArray(http(url))
                if (arr.length() == 0) break
                for (k in 0 until arr.length()) {
                    val a = arr.getJSONArray(k)
                    out.add(Candle(a.getLong(0), a.getDouble(1), a.getDouble(2), a.getDouble(3), a.getDouble(4)))
                }
                cur = out.last().t + 60000
                if (arr.length() < 1000 || cur >= to) break
            }
        } else {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/${m.sym}=X?interval=1m&period1=${from / 1000}&period2=${to / 1000}"
            val res = JSONObject(http(url)).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
            val ts = res.optJSONArray("timestamp") ?: return out
            val q = res.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
            val o = q.getJSONArray("open")
            val hi = q.getJSONArray("high")
            val lo = q.getJSONArray("low")
            val cl = q.getJSONArray("close")
            for (k in 0 until ts.length()) {
                if (o.isNull(k) || hi.isNull(k) || lo.isNull(k) || cl.isNull(k)) continue
                out.add(Candle(ts.getLong(k) * 1000, o.getDouble(k), hi.getDouble(k), lo.getDouble(k), cl.getDouble(k)))
            }
        }
        return out
    }

    private fun closedOnly(l: List<Candle>, now: Long): List<Candle> = l.filter { it.t + 60000 <= now }

    fun ensure(m: Market, days: Int) {
        val have = data[m.sym]
        if (have != null && have.size >= 400) return
        val now = System.currentTimeMillis()
        data[m.sym] = ArrayList(closedOnly(fetchRange(m, now - days * 86400000L, now), now))
    }

    fun refresh(m: Market) {
        val now = System.currentTimeMillis()
        val list = data[m.sym]
        if (list == null) { ensure(m, 5); return }
        val from = synchronized(list) { if (list.isEmpty()) now - 1800000L else list.last().t - 300000L }
        val fresh = closedOnly(fetchRange(m, from, now), now)
        synchronized(list) {
            for (c in fresh) {
                val idx = list.indexOfLast { it.t == c.t }
                if (idx >= 0) list[idx] = c
                else if (list.isEmpty() || c.t > list.last().t) list.add(c)
            }
            while (list.size > 8000) list.removeAt(0)
        }
    }

    fun ensureAll(ms: List<Market>, days: Int) {
        pool.invokeAll(ms.map { m -> Callable<Unit> { try { ensure(m, days) } catch (e: Exception) { } } })
    }

    fun refreshAll(ms: List<Market>) {
        pool.invokeAll(ms.map { m -> Callable<Unit> { try { refresh(m) } catch (e: Exception) { } } })
    }

    fun candles(m: Market): List<Candle> {
        val l = data[m.sym] ?: return emptyList()
        return synchronized(l) { ArrayList(l) }
    }

    fun lastPrice(m: Market): Double {
        if (!m.forex)
            return JSONObject(http("https://data-api.binance.vision/api/v3/ticker/price?symbol=${m.sym}")).getString("price").toDouble()
        val now = System.currentTimeMillis() / 1000
        val url = "https://query1.finance.yahoo.com/v8/finance/chart/${m.sym}=X?interval=1m&period1=${now - 600}&period2=${now + 60}"
        val res = JSONObject(http(url)).getJSONObject("chart").getJSONArray("result").getJSONObject(0)
        return res.getJSONObject("meta").getDouble("regularMarketPrice")
    }
}
