package com.signals.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var progressView: TextView
    private lateinit var results: LinearLayout
    private lateinit var logView: TextView
    private lateinit var rgMode: RadioGroup
    private lateinit var etSingle: EditText
    private lateinit var cbA: CheckBox
    private lateinit var cbB: CheckBox
    private lateinit var cbC: CheckBox
    private lateinit var etExp: EditText
    private lateinit var etWin: EditText
    private lateinit var etPay: EditText
    private lateinit var cbRed: CheckBox
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            statusView.text = Store.getStatus(this@MainActivity) + "\n" + Store.scoreText(this@MainActivity)
            logView.text = Store.readLog(this@MainActivity).ifBlank { "No signals yet." }
            h.postDelayed(this, 2000)
        }
    }

    private fun readCfg(): Cfg {
        val g = Cfg()
        g.mode = when (rgMode.checkedRadioButtonId) { 201 -> 0; 202 -> 1; 203 -> 2; else -> 3 }
        g.single = etSingle.text.toString().trim().uppercase()
        g.strats = (if (cbA.isChecked) "A" else "") + (if (cbB.isChecked) "B" else "") + (if (cbC.isChecked) "C" else "")
        if (g.strats.isEmpty()) g.strats = "C"
        g.expiryMin = (etExp.text.toString().toIntOrNull() ?: 2).coerceIn(1, 15)
        g.windowSec = (etWin.text.toString().toIntOrNull() ?: 20).coerceIn(5, 50)
        g.payout = (etPay.text.toString().toIntOrNull() ?: 85).coerceIn(50, 100) / 100.0
        g.alertRed = cbRed.isChecked
        return g
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun showRows(rows: List<Pair<String, Int>>) {
        results.removeAllViews()
        for ((text, level) in rows) {
            val tv = TextView(this)
            tv.text = text
            tv.setTextColor(Color.BLACK)
            tv.setPadding(24, 20, 24, 20)
            tv.setBackgroundColor(
                when (level) {
                    0 -> 0xFFFFCDD2.toInt()
                    1 -> 0xFFFFE0B2.toInt()
                    2 -> 0xFFC8E6C9.toInt()
                    else -> 0xFFEEEEEE.toInt()
                }
            )
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 8, 0, 8)
            results.addView(tv, lp)
        }
    }

    private fun runJob(job: ((String) -> Unit) -> List<Pair<String, Int>>) {
        results.removeAllViews()
        progressView.text = "Working… (first run downloads 5 days of data, can take a minute)"
        Thread {
            val rows = try {
                job { p -> runOnUiThread { progressView.text = p } }
            } catch (e: Exception) {
                listOf(Pair("Error: ${e.message}", -1))
            }
            runOnUiThread { progressView.text = ""; showRows(rows) }
        }.start()
    }

    private fun marketsFor(g: Cfg): List<Market> = if (g.mode == 3) Markets.forMode(0, "") else Markets.forMode(g.mode, g.single)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val cfg = Store.loadCfg(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 48, 32, 32)

        fun label(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 16f
            v.setPadding(0, 28, 0, 4)
            return v
        }

        val title = TextView(this)
        title.text = "Signal Alert"
        title.textSize = 24f
        root.addView(title)

        statusView = TextView(this)
        root.addView(statusView)

        root.addView(label("Markets to monitor"))
        rgMode = RadioGroup(this)
        val labels = listOf("All markets (crypto + forex)", "Crypto only", "Forex only", "Single pair")
        for ((k, t) in labels.withIndex()) {
            val rb = RadioButton(this)
            rb.text = t
            rb.id = 201 + k
            rgMode.addView(rb)
        }
        rgMode.check(201 + cfg.mode)
        root.addView(rgMode)
        etSingle = EditText(this)
        etSingle.hint = "Pair, e.g. BTCUSDT or EURUSD"
        etSingle.setText(cfg.single)
        root.addView(etSingle)

        root.addView(label("Strategies"))
        cbA = CheckBox(this); cbA.text = "A – original indicators"; cbA.isChecked = cfg.strats.contains('A')
        cbB = CheckBox(this); cbB.text = "B – pullback system"; cbB.isChecked = cfg.strats.contains('B')
        cbC = CheckBox(this); cbC.text = "C – regime + multi-timeframe confluence"; cbC.isChecked = cfg.strats.contains('C')
        root.addView(cbA); root.addView(cbB); root.addView(cbC)

        root.addView(label("Expiry (minutes) · entry window (seconds) · broker payout (%)"))
        etExp = EditText(this); etExp.inputType = InputType.TYPE_CLASS_NUMBER; etExp.setText(cfg.expiryMin.toString())
        etWin = EditText(this); etWin.inputType = InputType.TYPE_CLASS_NUMBER; etWin.setText(cfg.windowSec.toString())
        etPay = EditText(this); etPay.inputType = InputType.TYPE_CLASS_NUMBER; etPay.setText((cfg.payout * 100).toInt().toString())
        root.addView(etExp); root.addView(etWin); root.addView(etPay)
        cbRed = CheckBox(this)
        cbRed.text = "Also alert RED (no-edge) signals — for demo forward-testing"
        cbRed.isChecked = cfg.alertRed
        root.addView(cbRed)

        fun btn(t: String, a: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { a() }
            root.addView(b)
        }

        btn("Start alerts") {
            val g = readCfg()
            if (g.mode == 3 && Markets.parse(g.single) == null) {
                toast("Enter a pair like BTCUSDT or EURUSD")
            } else {
                Store.save(this, g)
                startForegroundService(Intent(this, SignalService::class.java))
            }
        }
        btn("Stop alerts") { stopService(Intent(this, SignalService::class.java)) }
        btn("Battery: allow background") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        btn("Check pair now") {
            val g = readCfg()
            val m = Markets.parse(g.single)
            if (m == null) toast("Enter a pair like BTCUSDT or EURUSD")
            else { Store.save(this, g); runJob { p -> Scan.render(listOf(m), g, p) } }
        }
        btn("Check all markets now") {
            val g = readCfg()
            Store.save(this, g)
            runJob { p -> Scan.render(marketsFor(g), g, p) }
        }
        btn("Backtest (5 days)") {
            val g = readCfg()
            Store.save(this, g)
            val ms = if (g.mode == 3) listOfNotNull(Markets.parse(g.single)) else Markets.forMode(g.mode, g.single)
            if (ms.isEmpty()) toast("Enter a valid pair")
            else runJob { p -> Scan.backtest(ms, g, p) }
        }

        progressView = TextView(this)
        root.addView(progressView)
        results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        root.addView(results)

        root.addView(label("Signal log"))
        logView = TextView(this)
        root.addView(logView)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
