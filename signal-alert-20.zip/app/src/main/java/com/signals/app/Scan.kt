package com.signals.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Row(val m: Market, val strat: Char, val sig: Signal, val v: Verdict, val lagSec: Long, val ref: Double)

object Scan {
    fun levelWord(l: Int) = when (l) {
        2 -> "🟢 STRONG"
        1 -> "🟠 LIKELY"
        else -> "🔴 NO"
    }

    fun render(ms: List<Market>, g: Cfg, progress: (String) -> Unit): List<Pair<String, Int>> {
        val e = g.expiryMin
        val missing = ms.filter { !Stats.has(it, e) }
        if (missing.isNotEmpty()) Stats.build(missing, g, progress)
        progress("Fetching latest candles…")
        Feed.refreshAll(ms)
        val now = System.currentTimeMillis()
        val rows = ArrayList<Row>()
        val closed = ArrayList<String>()
        val states = ArrayList<String>()
        var live = 0
        for (m in ms) {
            val cs = Feed.candles(m).takeLast(1500)
            if (cs.size < 330) { closed.add(m.label); continue }
            val last = cs.last()
            val lag = now - (last.t + 60000)
            if (lag > (if (m.forex) 180000L else 120000L)) { closed.add(m.label); continue }
            live++
            val s = Series(cs, g)
            val i = cs.size - 1
            if (ms.size == 1) {
                val trend = if (s.close[i] > s.ema5[i]) "above" else "below"
                states.add("${m.label} now: ADX ${s.adx[i].toInt()} · price $trend M5 EMA50 · RSI(7) ${s.rsi7[i].toInt()} · volatility ${"%.1f".format(s.atr[i] / s.atrAvg[i])}× avg")
            }
            for (st in g.strats) {
                val sig = Strategies.evaluate(s, i, st, m.forex) ?: continue
                rows.add(Row(m, st, sig, Stats.verdict(st, m, e, g.payout), lag / 1000, s.close[i]))
            }
        }
        rows.sortWith(compareByDescending<Row> { it.v.level }.thenByDescending { it.v.prob })
        val f = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val out = ArrayList<Pair<String, Int>>()
        out.add(Pair("Scan ${f.format(Date(now))} · $live/${ms.size} markets live · expiry $e min · break-even ${"%.1f".format(100.0 / (1.0 + g.payout))}%", -1))
        for (st in states) out.add(Pair(st, -1))
        if (rows.isEmpty()) {
            out.add(Pair("No qualified setup right now → do not trade this minute.", -1))
        }
        for ((k, r) in rows.withIndex()) {
            val dirTxt = if (r.sig.dir > 0) "CALL ▲" else "PUT ▼"
            val stale = r.lagSec > g.windowSec
            val head = (if (k == 0) "BEST · " else "") + "${levelWord(r.v.level)} · $dirTxt ${r.m.label} · Strategy ${r.strat}"
            val body = "Win est. ${"%.1f".format(r.v.prob * 100)}% · expiry $e min\n${r.sig.reason}\n${r.v.note}\n" +
                "Signal age ${r.lagSec}s" + (if (stale) " — window (${g.windowSec}s) passed, wait for the next setup" else " — enter now")
            out.add(Pair("$head\n$body", if (stale) -1 else r.v.level))
        }
        if (closed.isNotEmpty()) out.add(Pair("Closed / no fresh data: ${closed.joinToString(", ")}", -1))
        return out
    }

    fun backtest(ms: List<Market>, g: Cfg, progress: (String) -> Unit): List<Pair<String, Int>> {
        Stats.build(ms, g, progress)
        return Stats.backtestRows(ms, g)
    }
}
