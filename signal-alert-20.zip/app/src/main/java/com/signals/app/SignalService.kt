package com.signals.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SignalService : Service() {
    data class Pending(val m: Market, val strat: Char, val dir: Int, val entry: Double, val candleT: Long)

    @Volatile private var running = false
    @Volatile private var gen = 0
    private var worker: Thread? = null
    private var cfg = Cfg()
    private var markets: List<Market> = emptyList()
    private val pending = ArrayList<Pending>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        cfg = Store.loadCfg(this)
        markets = Markets.forMode(cfg.mode, cfg.single)
        createChannels()
        val n = statusNotif("Starting…")
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        worker?.interrupt()
        gen++
        val myGen = gen
        running = true
        val t = Thread { loop(myGen) }
        worker = t
        t.start()
        return START_STICKY
    }

    private fun alive(g: Int) = running && g == gen

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("status", "Status", NotificationManager.IMPORTANCE_LOW))
        val ch = NotificationChannel("signals", "Trade signals", NotificationManager.IMPORTANCE_HIGH)
        ch.enableVibration(true)
        nm.createNotificationChannel(ch)
    }

    private fun statusNotif(text: String): Notification =
        Notification.Builder(this, "status")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Signal Alert running")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    private fun status(text: String) {
        Store.setStatus(this, text)
        getSystemService(NotificationManager::class.java).notify(1, statusNotif(text))
    }

    private fun loop(g: Int) {
        try {
            if (markets.isEmpty()) {
                status("No valid market selected — stop and fix the pair name")
                return
            }
            status("Loading 5 days of history for ${markets.size} market(s)…")
            Stats.build(markets, cfg) { status(it) }
            status("Watching ${markets.size} market(s) · waiting for next candle close")
            while (alive(g)) {
                val now = System.currentTimeMillis()
                val next = (now / 60000 + 1) * 60000 + 3000
                Thread.sleep(next - now)
                if (!alive(g)) break
                try { tick() } catch (e: Exception) { status("Scan error: ${e.message}") }
                if (System.currentTimeMillis() - Stats.builtAt > 3600000L)
                    Stats.build(markets, cfg) { }
            }
        } catch (e: InterruptedException) {
        }
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        Feed.refreshAll(markets)
        resolvePending()
        val found = ArrayList<Row>()
        var live = 0
        for (m in markets) {
            val cs = Feed.candles(m).takeLast(1500)
            if (cs.size < 330) continue
            val last = cs.last()
            val lag = now - (last.t + 60000)
            if (lag > (if (m.forex) 120000L else 30000L)) continue
            live++
            val s = Series(cs, cfg)
            val i = cs.size - 1
            for (st in cfg.strats) {
                val sig = Strategies.evaluate(s, i, st, m.forex) ?: continue
                found.add(Row(m, st, sig, Stats.verdict(st, m, cfg.expiryMin, cfg.payout), lag / 1000, s.close[i]))
                pending.add(Pending(m, st, sig.dir, s.close[i], last.t))
            }
        }
        while (pending.size > 200) pending.removeAt(0)
        found.sortWith(compareByDescending<Row> { it.v.level }.thenByDescending { it.v.prob })
        val best = found.firstOrNull()
        val alerted = best != null && (best.v.level >= 1 || cfg.alertRed)
        var st = "Last scan ${fmt.format(Date(now))} · $live/${markets.size} markets live · ${found.size} setup(s)"
        if (best != null && !alerted) st += " · muted (no proven edge)"
        status(st)
        for (r in found) {
            val d = if (r.sig.dir > 0) "CALL ▲" else "PUT ▼"
            Store.log(this, "${fmt.format(Date(now))} ${Scan.levelWord(r.v.level)} $d ${r.m.label} (${r.strat}) ${"%.1f".format(r.v.prob * 100)}% — ${r.sig.reason}")
        }
        if (alerted && best != null) fire(best, found)
    }

    private fun fire(b: Row, all: List<Row>) {
        val now = System.currentTimeMillis()
        val until = now + cfg.windowSec * 1000L
        val dirTxt = if (b.sig.dir > 0) "CALL ▲" else "PUT ▼"
        val color = when (b.v.level) {
            2 -> 0xFF2E7D32.toInt()
            1 -> 0xFFEF6C00.toInt()
            else -> 0xFFC62828.toInt()
        }
        val title = "${Scan.levelWord(b.v.level)} · $dirTxt ${b.m.label}"
        val others = all.filter { it !== b }.take(2)
            .joinToString("; ") { "${it.m.label} ${if (it.sig.dir > 0) "CALL" else "PUT"} (${(it.v.prob * 100).toInt()}%)" }
        val text = "Win est. ${"%.1f".format(b.v.prob * 100)}% (break-even ${"%.1f".format(100.0 / (1.0 + cfg.payout))}%) · Strategy ${b.strat} · M1 signal, expiry ${cfg.expiryMin} min\n" +
            "Enter ${fmt.format(Date(now))}–${fmt.format(Date(until))} only, then skip.\n${b.sig.reason}" +
            (if (others.isNotEmpty()) "\nAlso: $others" else "")
        notify(2, "signals", title, text, cfg.windowSec * 1000L, color)
        watch(b, until)
    }

    // Cancels the alert early if price runs more than 0.25 ATR away from the signal price (either way).
    private fun watch(b: Row, until: Long) {
        Thread {
            try {
                while (System.currentTimeMillis() < until && running) {
                    Thread.sleep(4000)
                    val p = Feed.lastPrice(b.m)
                    val move = (p - b.ref) * b.sig.dir
                    if (move > 0.25 * b.sig.atr) { invalidate("${b.m.label}: price already ran with the signal — skip"); return@Thread }
                    if (move < -0.25 * b.sig.atr) { invalidate("${b.m.label}: price moved against the signal — skip"); return@Thread }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun invalidate(msg: String) {
        getSystemService(NotificationManager::class.java).cancel(2)
        notify(3, "status", "Signal expired", msg, 20000L, 0xFF757575.toInt())
        Store.log(this, "   ↳ expired: $msg")
    }

    private fun resolvePending() {
        val e = cfg.expiryMin
        val now = System.currentTimeMillis()
        val iter = pending.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            val target = p.candleT + e * 60000L
            if (now - (target + 60000) > 10 * 60000L) { iter.remove(); continue }
            val res = Feed.candles(p.m).takeLast(30).firstOrNull { it.t == target } ?: continue
            Store.addResult(this, p.strat, (res.c - p.entry) * p.dir > 0)
            iter.remove()
        }
    }

    private fun notify(id: Int, channel: String, title: String, text: String, timeoutMs: Long, color: Int) {
        val n = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setColor(color)
            .setTimeoutAfter(timeoutMs)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(id, n)
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }
}
