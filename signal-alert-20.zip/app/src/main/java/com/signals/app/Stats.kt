package com.signals.app

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sqrt

data class Stat(var n: Int = 0, var w: Int = 0)
data class Verdict(val prob: Double, val level: Int, val note: String)

object Stats {
    private val per = ConcurrentHashMap<String, Stat>()
    @Volatile var builtAt = 0L

    fun has(m: Market, e: Int) = per.containsKey("A|${m.sym}|$e")

    // Replays every strategy over ~5 days of 1-minute candles. Entry = close of signal candle, exit = close `e` candles later.
    fun build(markets: List<Market>, cfg: Cfg, progress: (String) -> Unit) {
        val e = cfg.expiryMin
        progress("Downloading history for ${markets.size} market(s)…")
        Feed.ensureAll(markets, 5)
        Feed.refreshAll(markets)
        for ((idx, m) in markets.withIndex()) {
            progress("Analysing ${m.label} (${idx + 1}/${markets.size})…")
            val cs = Feed.candles(m)
            if (cs.size < 330 + e) continue
            val s = Series(cs, cfg)
            for (st in listOf('A', 'B', 'C')) {
                val stat = Stat()
                for (i in 320 until cs.size - e) {
                    val sig = Strategies.evaluate(s, i, st, m.forex) ?: continue
                    stat.n++
                    if ((s.close[i + e] - s.close[i]) * sig.dir > 0) stat.w++
                }
                per["$st|${m.sym}|$e"] = stat
            }
        }
        builtAt = System.currentTimeMillis()
    }

    private fun pool(st: Char, forex: Boolean, e: Int): Stat {
        val tot = Stat()
        for ((k, v) in per) {
            val p = k.split("|")
            if (p[0] == st.toString() && p[2] == e.toString() && (!p[1].endsWith("USDT")) == forex) {
                tot.n += v.n
                tot.w += v.w
            }
        }
        return tot
    }

    // Likelihood = this market's 5-day record shrunk toward the strategy's pooled record (30 pseudo-trades).
    // GREEN: conservative lower bound clears break-even. ORANGE: estimate clears break-even, bound does not. RED: otherwise.
    fun verdict(st: Char, m: Market, e: Int, payout: Double): Verdict {
        val own = per["$st|${m.sym}|$e"] ?: Stat()
        val pl = pool(st, m.forex, e)
        val be = 1.0 / (1.0 + payout)
        if (pl.n < 50)
            return Verdict(0.5, 0, "Not enough 5-day history for this strategy yet (${pl.n} signals) — treat as NO")
        val prior = pl.w.toDouble() / pl.n
        val k = 30.0
        val post = (own.w + k * prior) / (own.n + k)
        val lower = post - 1.28 * sqrt(post * (1 - post) / (own.n + k))
        val level = if (lower >= be) 2 else if (post >= be) 1 else 0
        val grp = if (m.forex) "forex" else "crypto"
        return Verdict(post, level,
            "5-day record: this market ${own.w}/${own.n}; all $grp ${pl.w}/${pl.n} (${"%.1f".format(prior * 100)}%)")
    }

    fun backtestRows(ms: List<Market>, g: Cfg): List<Pair<String, Int>> {
        val e = g.expiryMin
        val be = 1.0 / (1.0 + g.payout)
        val out = ArrayList<Pair<String, Int>>()
        out.add(Pair("Backtest ≈5 days · ${ms.size} market(s) · expiry $e min · break-even ${"%.1f".format(be * 100)}% (payout ${(g.payout * 100).toInt()}%)", -1))
        for (st in g.strats) {
            var n = 0
            var w = 0
            val parts = ArrayList<Pair<Market, Stat>>()
            for (m in ms) {
                val s = per["$st|${m.sym}|$e"] ?: continue
                n += s.n
                w += s.w
                parts.add(Pair(m, s))
            }
            if (n == 0) { out.add(Pair("Strategy $st: no signals (or no data)", -1)); continue }
            val p = w.toDouble() / n
            val lower = p - 1.28 * sqrt(p * (1 - p) / n)
            val level = if (n < 50) 0 else if (lower >= be) 2 else if (p >= be) 1 else 0
            val word = when (level) {
                2 -> "above break-even (statistically)"
                1 -> "slightly above break-even, not proven"
                else -> if (n < 50) "too few signals to judge" else "no edge"
            }
            val best = parts.filter { it.second.n >= 10 }
                .sortedByDescending { it.second.w.toDouble() / it.second.n }
                .take(3)
                .joinToString(", ") { "${it.first.label} ${(100.0 * it.second.w / it.second.n).toInt()}% (${it.second.n})" }
            out.add(Pair("Strategy $st: $n signals, win ${"%.1f".format(p * 100)}% → $word\nBest markets (selection bias, don't trust): ${if (best.isEmpty()) "n/a" else best}", level))
        }
        return out
    }
}
