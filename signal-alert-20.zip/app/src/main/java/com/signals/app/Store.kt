package com.signals.app

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", Context.MODE_PRIVATE)

    fun loadCfg(c: Context): Cfg {
        val sp = p(c)
        return Cfg(
            expiryMin = sp.getInt("exp", 2),
            windowSec = sp.getInt("win", 20),
            payout = sp.getInt("pay", 85) / 100.0,
            strats = sp.getString("strats", "ABC") ?: "ABC",
            mode = sp.getInt("mode", 0),
            single = sp.getString("single", "BTCUSDT") ?: "BTCUSDT",
            alertRed = sp.getBoolean("red", false)
        )
    }

    fun save(c: Context, g: Cfg) {
        p(c).edit()
            .putString("strats", g.strats).putInt("mode", g.mode).putString("single", g.single)
            .putInt("exp", g.expiryMin).putInt("win", g.windowSec)
            .putInt("pay", (g.payout * 100).toInt()).putBoolean("red", g.alertRed).apply()
    }

    @Synchronized
    fun log(c: Context, line: String) {
        val old = (p(c).getString("log", "") ?: "").split("\n").filter { it.isNotBlank() }
        val n = (listOf(line) + old).take(60)
        p(c).edit().putString("log", n.joinToString("\n")).apply()
    }

    fun readLog(c: Context): String = p(c).getString("log", "") ?: ""

    fun setStatus(c: Context, s: String) { p(c).edit().putString("status", s).apply() }
    fun getStatus(c: Context): String = p(c).getString("status", "Not running") ?: "Not running"

    @Synchronized
    fun addResult(c: Context, strat: Char, win: Boolean) {
        val k = (if (win) "w_" else "l_") + strat
        val sp = p(c)
        sp.edit().putInt(k, sp.getInt(k, 0) + 1).apply()
    }

    fun scoreText(c: Context): String {
        val sp = p(c)
        val sb = StringBuilder("Live forward-test (every signal, incl. muted): ")
        var any = false
        for (s in listOf("A", "B", "C")) {
            val w = sp.getInt("w_$s", 0)
            val l = sp.getInt("l_$s", 0)
            if (w + l > 0) {
                any = true
                sb.append("$s $w-$l (${100 * w / (w + l)}%)  ")
            }
        }
        if (!any) sb.append("none resolved yet")
        return sb.toString()
    }
}
