package com.signals.app

import kotlin.math.abs

data class Signal(val dir: Int, val reason: String, val atr: Double)

data class Cfg(
    var jp: Int = 15, var js: Int = 7,
    var tp: Int = 10, var ts: Int = 6,
    var lp: Int = 5, var ls: Int = 4,
    var demP: Int = 10, var momP: Int = 12,
    var adxMin: Double = 22.0,
    var expiryMin: Int = 2,
    var windowSec: Int = 20,
    var payout: Double = 0.85,
    var strats: String = "ABC",
    var mode: Int = 0,
    var single: String = "BTCUSDT",
    var alertRed: Boolean = false
)

// All indicators computed once over the candle list, so strategies can be evaluated at any index cheaply.
class Series(val c: List<Candle>, val g: Cfg) {
    val n = c.size
    val close = DoubleArray(n) { c[it].c }
    private val med = DoubleArray(n) { (c[it].h + c[it].l) / 2 }
    private val jr = Ind.smma(med, g.jp)
    private val teethR = Ind.smma(med, g.tp)
    private val lr = Ind.smma(med, g.lp)
    val dem = Ind.demarker(c, g.demP)
    val mom = Ind.momentum(c, g.momP)
    val atr = Ind.atr(c, 14)
    val adx = Ind.adx(c, 14)
    val ema5 = Ind.htfEma(close, 5, 50)
    val ema15 = Ind.htfEma(close, 15, 50)
    val rsi7 = Ind.rsi(close, 7)
    val bb = Ind.bollinger(close, 20, 2.2)
    val atrAvg: DoubleArray = Ind.sma(DoubleArray(n) { if (atr[it].isNaN()) 0.0 else atr[it] }, 100)
    fun jaw(i: Int) = Ind.shifted(jr, g.js, i)
    fun teeth(i: Int) = Ind.shifted(teethR, g.ts, i)
    fun lips(i: Int) = Ind.shifted(lr, g.ls, i)
}

object Strategies {
    fun evaluate(s: Series, i: Int, strat: Char, forex: Boolean): Signal? {
        if (i < 320 || i >= s.n) return null
        val atrV = s.atr[i]
        if (atrV.isNaN() || atrV <= 0.0) return null
        val bull = s.lips(i) > s.teeth(i) && s.teeth(i) > s.jaw(i)
        val bear = s.lips(i) < s.teeth(i) && s.teeth(i) < s.jaw(i)
        return when (strat) {
            'A' -> stratA(s, i, bull, bear, atrV)
            'B' -> stratB(s, i, bull, bear, atrV)
            'C' -> stratC(s, i, bull, bear, atrV, forex)
            else -> null
        }
    }

    private fun stratA(s: Series, i: Int, bull: Boolean, bear: Boolean, atrV: Double): Signal? {
        if (bull && s.mom[i] > 0 && s.dem[i - 1] <= 0.5 && s.dem[i] > 0.5)
            return Signal(1, "Alligator bullish + Momentum>0 + DeMarker crossed up 0.5", atrV)
        if (bear && s.mom[i] < 0 && s.dem[i - 1] >= 0.5 && s.dem[i] < 0.5)
            return Signal(-1, "Alligator bearish + Momentum<0 + DeMarker crossed down 0.5", atrV)
        return null
    }

    private fun stratB(s: Series, i: Int, bull: Boolean, bear: Boolean, atrV: Double): Signal? {
        val adx = s.adx[i]
        if (adx.isNaN() || adx < s.g.adxMin) return null
        val c = s.c
        val m5Up = s.close[i] > s.ema5[i]
        val m5Dn = s.close[i] < s.ema5[i]
        val widening = abs(s.lips(i) - s.jaw(i)) > abs(s.lips(i - 3) - s.jaw(i - 3))
        if (bull && widening && m5Up && s.dem[i - 1] <= 0.30 && s.dem[i] > 0.30 &&
            s.mom[i] > s.mom[i - 1] && c[i].c > c[i].o && c[i].c > s.jaw(i))
            return Signal(1, "Uptrend pullback ended: ADX ${adx.toInt()}, M5 up, DeMarker back above 0.30", atrV)
        if (bear && widening && m5Dn && s.dem[i - 1] >= 0.70 && s.dem[i] < 0.70 &&
            s.mom[i] < s.mom[i - 1] && c[i].c < c[i].o && c[i].c < s.jaw(i))
            return Signal(-1, "Downtrend pullback ended: ADX ${adx.toInt()}, M5 down, DeMarker back below 0.70", atrV)
        return null
    }

    // Strategy C: regime-switching multi-timeframe confluence.
    // Trending (ADX>=25): buy/sell pullbacks that agree with M1 Alligator, M5 and M15 trend, RSI(7) recovery, strong trigger candle.
    // Ranging (ADX<=20): fade Bollinger(20,2.2) band rejections with RSI(7) extreme and a long rejection wick, near the M15 mean.
    // Filters: volatility not dead/spiking (ATR 0.6-2.0x its 100-bar average); forex only 07:00-17:00 UTC on weekdays.
    private fun stratC(s: Series, i: Int, bull: Boolean, bear: Boolean, atrV: Double, forex: Boolean): Signal? {
        val cd = s.c
        val t = cd[i].t
        if (forex) {
            val hour = ((t / 3600000L) % 24).toInt()
            val dow = (((t / 86400000L) + 4) % 7).toInt()
            if (dow == 0 || dow == 6 || hour < 7 || hour >= 17) return null
        }
        val ar = atrV / s.atrAvg[i]
        if (ar.isNaN() || ar < 0.6 || ar > 2.0) return null
        val a = s.adx[i]
        if (a.isNaN()) return null
        val k = cd[i]
        val range = k.h - k.l
        if (range <= 0.0) return null
        val closePos = (k.c - k.l) / range
        val lowerW = (minOf(k.o, k.c) - k.l) / range
        val upperW = (k.h - maxOf(k.o, k.c)) / range
        val cl = s.close[i]
        if (a >= 25.0) {
            val upTrend = bull && cl > s.ema5[i] && cl > s.ema15[i]
            val dnTrend = bear && cl < s.ema5[i] && cl < s.ema15[i]
            val dipped = (1..4).any { s.rsi7[i - it] <= 35.0 }
            val popped = (1..4).any { s.rsi7[i - it] >= 65.0 }
            if (upTrend && dipped && s.rsi7[i - 1] <= 40.0 && s.rsi7[i] > 40.0 && k.c > k.o && closePos >= 0.6)
                return Signal(1, "Trend pullback (ADX ${a.toInt()}): M1+M5+M15 up, RSI recovered", atrV)
            if (dnTrend && popped && s.rsi7[i - 1] >= 60.0 && s.rsi7[i] < 60.0 && k.c < k.o && closePos <= 0.4)
                return Signal(-1, "Trend pullback (ADX ${a.toInt()}): M1+M5+M15 down, RSI rolled over", atrV)
        } else if (a <= 20.0) {
            val lo = s.bb[2][i]
            val up = s.bb[1][i]
            val nearMean = abs(cl - s.ema15[i]) < 3.0 * atrV
            if (nearMean && k.l < lo && cl > lo && lowerW >= 0.5 && (s.rsi7[i] <= 35.0 || s.rsi7[i - 1] <= 30.0))
                return Signal(1, "Range reversal (ADX ${a.toInt()}): rejected lower Bollinger band", atrV)
            if (nearMean && k.h > up && cl < up && upperW >= 0.5 && (s.rsi7[i] >= 65.0 || s.rsi7[i - 1] >= 70.0))
                return Signal(-1, "Range reversal (ADX ${a.toInt()}): rejected upper Bollinger band", atrV)
        }
        return null
    }
}
